Taller POO (Java + Swing)
==============================================

Autor: Maikol barrios

Contenido:
- Proyecto Java para NetBeans con clases:
  Empleado, Desarrollador, Gerente, Practicante.
- Interfaz Swing (empleados.MainGUI) con botones para:
  Agregar Desarrollador, Agregar Gerente, Agregar Practicante, Mostrar Empleados.
- Validaciones: no permite IDs duplicados ni salarios negativos.
- Persistencia básica: guarda y carga empleados en "employees.txt" en la carpeta del proyecto.

Ejecutar en NetBeans:
1. File -> Open Project -> Selecciona la carpeta "Taller maikol".
2. Run -> Run Project.

Ejecutar desde línea de comandos:
1. Compilar: javac -d bin -sourcepath src src/empleados/*.java
2. Ejecutar: java -cp bin empleados.MainGUI
