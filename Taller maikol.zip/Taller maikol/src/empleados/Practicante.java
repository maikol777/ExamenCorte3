package empleados;

public class Practicante extends Empleado {
    private String universidad;
    private int semestre;

    public Practicante(String nombre, String id, double salario, String universidad, int semestre) {
        super(nombre, id, salario);
        this.universidad = universidad;
        this.semestre = semestre;
    }

    public String getUniversidad() {
        return universidad;
    }

    public int getSemestre() {
        return semestre;
    }

    @Override
    public String mostrarInfo() {
        return String.format("Practicante - %s | Universidad: %s | Semestre: %d", super.mostrarInfo(), universidad, semestre);
    }
}
