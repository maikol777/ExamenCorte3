package empleados;

/**
 * Gestor de empleados - Maneja el almacenamiento y gestión de empleados
 * @author Maikol
 * @version 1.0
 * @location ~/Escritorio/Taller maikol
 */

import java.util.*;
import java.io.*;

public class EmpleadoManager {
    private List<Empleado> empleados;
    private File storageFile;

    
    public EmpleadoManager(File storageFile) {
        this.storageFile = storageFile;
        this.empleados = new ArrayList<>();
        load(); 
    }

  
    public synchronized boolean idExists(String id) {
        if (id == null) return false;
        for (Empleado e : empleados) {
            if (id.equals(e.getId())) return true;
        }
        return false;
    }

    public synchronized boolean addEmpleado(Empleado e) {
        if (e == null) return false;
        if (e.getSalario() < 0) return false; 
        save(); 
        return true;
    }

    public synchronized List<Empleado> getEmpleados() {
        return new ArrayList<>(empleados);
    }

   
    private void load() {
        if (!storageFile.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(storageFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\|");
                if (parts.length < 4) {
                    System.err.println("Línea ignorada (formato inválido): " + line);
                    continue;
                }

                String type = parts[0];
                String nombre = parts[1];
                String id = parts[2];
                double salario;
                try {
                    salario = Double.parseDouble(parts[3]);
                } catch (NumberFormatException ex) {
                    System.err.println("Salario inválido en línea: " + line);
                    continue;
                }

                try {
                    switch (type) {
                        case "DEV": {
                            String lang = parts.length > 4 ? parts[4] : "";
                            empleados.add(new Desarrollador(nombre, id, salario, lang));
                            break;
                        }
                        case "GER": {
                            int tam = parts.length > 4 ? safeParseInt(parts[4]) : 0;
                            empleados.add(new Gerente(nombre, id, salario, tam));
                            break;
                        }
                        case "PRA": {
                            String uni = parts.length > 4 ? parts[4] : "";
                            int sem = parts.length > 5 ? safeParseInt(parts[5]) : 0;
                            empleados.add(new Practicante(nombre, id, salario, uni, sem));
                            break;
                        }
                        default:
                            empleados.add(new Empleado(nombre, id, salario));
                            break;
                    }
                } catch (Exception ex) {
                    System.err.println("Error creando empleado desde línea: " + line + " -> " + ex.getMessage());
                }
            }
        } catch (IOException ex) {
            System.err.println("Error leyendo archivo de almacenamiento: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private void save() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(storageFile))) {
            for (Empleado e : empleados) {
                String line = formatEmpleado(e);
                writer.println(line);
            }
        } catch (IOException ex) {
            System.err.println("Error guardando archivo de almacenamiento: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    private String formatEmpleado(Empleado e) {
        if (e instanceof Desarrollador d) {
            return String.join("|", "DEV", d.getNombre(), d.getId(), String.valueOf(d.getSalario()), d.getLenguajeProgramacion());
        } else if (e instanceof Gerente g) {
            return String.join("|", "GER", g.getNombre(), g.getId(), String.valueOf(g.getSalario()), String.valueOf(g.getTamanoEquipo()));
        } else if (e instanceof Practicante p) {
            return String.join("|", "PRA", p.getNombre(), p.getId(), String.valueOf(p.getSalario()), p.getUniversidad(), String.valueOf(p.getSemestre()));
        } else {
            return String.join("|", "EMP", e.getNombre(), e.getId(), String.valueOf(e.getSalario()));
        }
    }

    private int safeParseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException ex) {
            return 0;
        }
    }
   
}