package empleados;

public class Desarrollador extends Empleado {
    private String lenguajeProgramacion;

    public Desarrollador(String nombre, String id, double salario, String lenguajeProgramacion) {
        super(nombre, id, salario);
        this.lenguajeProgramacion = lenguajeProgramacion;
    }

    public String getLenguajeProgramacion() {
        return lenguajeProgramacion;
    }

    @Override
    public String mostrarInfo() {
        return String.format("Desarrollador - %s | Lenguaje: %s", super.mostrarInfo(), lenguajeProgramacion);
    }
}
