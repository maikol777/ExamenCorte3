package empleados;

/**
 * Clase principal del sistema de gestión de empleados
 * @author Maikol
 * @version 1.0
 * @location ~/Escritorio/Taller maikol
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class Principal{
    private JFrame frame;
    private JTextArea outputArea;
    private EmpleadoManager manager;

    public Principal() {
        // storage file in project root named employees.txt
        File storage = new File("employees.txt");
        manager = new EmpleadoManager(storage);
        init();
    }

    private void init() {
        frame = new JFrame("Gestión de Empleados - Maikol");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(700, 450);
        frame.setLocationRelativeTo(null);

        JPanel topPanel = new JPanel();
        JButton btnDev = new JButton("Agregar Desarrollador");
        JButton btnGer = new JButton("Agregar Gerente");
        JButton btnPra = new JButton("Agregar Practicante");
        JButton btnShow = new JButton("Mostrar Empleados");

        topPanel.add(btnDev);
        topPanel.add(btnGer);
        topPanel.add(btnPra);
        topPanel.add(btnShow);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scroll = new JScrollPane(outputArea);

        frame.getContentPane().setLayout(new BorderLayout());
        frame.getContentPane().add(topPanel, BorderLayout.NORTH);
        frame.getContentPane().add(scroll, BorderLayout.CENTER);

        btnDev.addActionListener(e -> agregarDesarrollador());
        btnGer.addActionListener(e -> agregarGerente());
        btnPra.addActionListener(e -> agregarPracticante());
        btnShow.addActionListener(e -> mostrarEmpleados());

        // show existing
        mostrarEmpleados();
        frame.setVisible(true);
    }

    private void agregarDesarrollador() {
        try {
            String nombre = JOptionPane.showInputDialog(frame, "Nombre:");
            if (nombre == null || nombre.trim().isEmpty()) return;
            String id = JOptionPane.showInputDialog(frame, "ID:");
            if (id == null || id.trim().isEmpty()) return;
            String salarioStr = JOptionPane.showInputDialog(frame, "Salario:");
            if (salarioStr == null) return;
            double salario = Double.parseDouble(salarioStr);
            if (salario < 0) { JOptionPane.showMessageDialog(frame, "Salario no puede ser negativo"); return; }
            if (manager.idExists(id)) { JOptionPane.showMessageDialog(frame, "ID ya existe"); return; }
            String lang = JOptionPane.showInputDialog(frame, "Lenguaje de programación:");
            if (lang == null) lang = "";
            Desarrollador d = new Desarrollador(nombre,id,salario,lang);
            manager.addEmpleado(d);
            JOptionPane.showMessageDialog(frame, "Desarrollador agregado");
            mostrarEmpleados();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Salario inválido");
        }
    }

    private void agregarGerente() {
        try {
            String nombre = JOptionPane.showInputDialog(frame, "Nombre:");
            if (nombre == null || nombre.trim().isEmpty()) return;
            String id = JOptionPane.showInputDialog(frame, "ID:");
            if (id == null || id.trim().isEmpty()) return;
            String salarioStr = JOptionPane.showInputDialog(frame, "Salario:");
            if (salarioStr == null) return;
            double salario = Double.parseDouble(salarioStr);
            if (salario < 0) { JOptionPane.showMessageDialog(frame, "Salario no puede ser negativo"); return; }
            if (manager.idExists(id)) { JOptionPane.showMessageDialog(frame, "ID ya existe"); return; }
            String tamStr = JOptionPane.showInputDialog(frame, "Tamaño del equipo (número):");
            if (tamStr == null) return;
            int tam = Integer.parseInt(tamStr);
            Gerente g = new Gerente(nombre,id,salario,tam);
            manager.addEmpleado(g);
            JOptionPane.showMessageDialog(frame, "Gerente agregado");
            mostrarEmpleados();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada numérica inválida");
        }
    }

    private void agregarPracticante() {
        try {
            String nombre = JOptionPane.showInputDialog(frame, "Nombre:");
            if (nombre == null || nombre.trim().isEmpty()) return;
            String id = JOptionPane.showInputDialog(frame, "ID:");
            if (id == null || id.trim().isEmpty()) return;
            String salarioStr = JOptionPane.showInputDialog(frame, "Salario:");
            if (salarioStr == null) return;
            double salario = Double.parseDouble(salarioStr);
            if (salario < 0) { JOptionPane.showMessageDialog(frame, "Salario no puede ser negativo"); return; }
            if (manager.idExists(id)) { JOptionPane.showMessageDialog(frame, "ID ya existe"); return; }
            String uni = JOptionPane.showInputDialog(frame, "Universidad:");
            if (uni == null) uni = "";
            String semStr = JOptionPane.showInputDialog(frame, "Semestre (número):");
            if (semStr == null) return;
            int sem = Integer.parseInt(semStr);
            Practicante p = new Practicante(nombre,id,salario,uni,sem);
            manager.addEmpleado(p);
            JOptionPane.showMessageDialog(frame, "Practicante agregado");
            mostrarEmpleados();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Entrada numérica inválida");
        }
    }

    private void mostrarEmpleados() {
        StringBuilder sb = new StringBuilder();
        for (Empleado e : manager.getEmpleados()) {
            sb.append(e.mostrarInfo()).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    public static void main(String[] args) {
        // Set simple look and feel
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ex) {}
        SwingUtilities.invokeLater(() -> new Principal());
    }
}
