package empleados;

public class Empleado {
    protected String nombre;
    protected String id;
    protected double salario;

    public Empleado(String nombre, String id, double salario) {
        this.nombre = nombre;
        this.id = id;
        this.salario = salario;
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public double getSalario() {
        return salario;
    }

    public String getId() {
        return id;
    }

    public String mostrarInfo() {
        return String.format("Nombre: %s | ID: %s | Salario: %.2f", nombre, id, salario);
    }

    @Override
    public String toString() {
        return mostrarInfo();
    }
}
