package empleados;

public class Gerente extends Empleado {
    private int tamanoEquipo;

    public Gerente(String nombre, String id, double salario, int tamanoEquipo) {
        super(nombre, id, salario);
        this.tamanoEquipo = tamanoEquipo;
    }

    public int getTamanoEquipo() {
        return tamanoEquipo;
    }

    @Override
    public String mostrarInfo() {
        return String.format("Gerente - %s | Tamaño equipo: %d", super.mostrarInfo(), tamanoEquipo);
    }
}
